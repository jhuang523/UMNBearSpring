from src.run_openkarst import run_openkarst_simulation, load_network_data, write_constant_head_boundary
from src.utils.common import print_verbose
import pandas as pd 
import numpy as np

def main(debug = True):
    #load network data
    network_dir = 'anastomotic_simple_clean'
    network_name = ""
    for p in network_dir.split('/'):
        if p not in ['.', 'networks']:
            if network_name == "":
                network_name = p
            else:
                network_name += f'_{p}'
    nodes_file = 'nodes.csv'
    edges_file = 'edges.csv'
    network = load_network_data(f'{network_dir}/{nodes_file}', f'{network_dir}/{edges_file}', debug= debug)
    network.extract_diffuse_inlets()
    if not network.network_validity():
        raise Exception("Network validity check failed.")

    #boundary conditions
    inflow_type = 'constant'
    baseflow= 0.02
    initial_flowrate = 1e-5
    initial_water_depth = 1e-5
    inflow_boundary = {network.diffuse_inlets + network.inlets : {'flow' : baseflow / len(network.diffuse_inlets + network.inlets)}}

    head_boundary = 0.01
    head_boundary = write_constant_head_boundary(network, head_boundary)
    head_type = 'constant'

    ss_output_dir =  f'output/spinup/{network_name}'
    t_ss_max = 86400*20
    #running manually and checking for convergence 
    ss_results = run_openkarst_simulation(network, 
                        initial_flowrate = initial_flowrate,
                        initial_water_depth = initial_water_depth,
                        inflow_boundary= inflow_boundary,
                        head_boundary= head_boundary,
                        steady_state = False,
                        dt_max = 1e3,
                        t_max = t_ss_max,
                        adaptive_timesteps = True,
                        inflow_type = inflow_type,
                        head_type = head_type,
                        save_path = ss_output_dir)
    
if __name__ == "__main__":
    main()